package umlexample;

public class Mathematics {
	private double x, y, r;
	
	
	//create getter method for each variable 
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getR() {
		return r;
	}

	//create setter method for each variable in the class. 
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void setR(double r) {
		this.r = r;
	}


	//Now write logic rectangle and circle. 
	public double areaRec()
	{
		double area = x*y;
		return area;
	}
	public double perRec()
	{
		double per = 2*(x+y);
		return per;
	}
	public double areaCircle()
	{
		double area = 3.14*r*r;
		return area;
	}
	public double circumCircle()
	{
		double circumference = 2*3.14*r;
		return circumference;
	}
}

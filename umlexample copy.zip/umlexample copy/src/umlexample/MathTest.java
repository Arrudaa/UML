package umlexample;

public class MathTest {

	public static void main(String[] args) {
		
		Mathematics math = new Mathematics(); //creating object. 
		
	//Set the values of the variables.
		math.setX(20.5);
		math.setY(30.5);
		math.setR(12.5);
		
	double areaRec = math.areaRec();
	double perRec = math.perRec();
	double areaCircle = math.areaCircle();
	double CicrumCircle = math.circumCircle();
	
	System.out.println("Area of rectangle: " + areaRec);
	System.out.println("Perimeter of rectangle: " + perRec);
	System.out.println("Area of circle: " + areaCircle);
	System.out.println("Cicumference of circle: " + CicrumCircle);
	
	

	}

}
